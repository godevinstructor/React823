// Get Sports News
const imgUrl = "./cat.jpg";
const defaultImg = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPW_I8UenrjOFNcZwdYaR0kE7-q1_J7wosliypHszQlA&s=10";

async function getSportsNews() { 
    const response = await fetch("https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=1a20ed3b070f4b8ab9663ee3e49b2a0c")
    const data = await response.json() // Return Body
    return data.articles
}

async function renderSportsNews() {
    const sportsNews = await getSportsNews();
    const row = document.querySelector(".row")

    for(let sportNew of sportsNews) { 
        const div = document.createElement("div")
        div.className = "col-lg-4 col-md-6 col-sm-12 my-2"
        div.innerHTML = `
            <div class="card" style="width: 18rem;">
                <img src="${sportNew.urlToImage ? sportNew.urlToImage 
                    : defaultImg}" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">${sportNew.title}</h5>
                    <p class="card-text">${sportNew.content ? sportNew.content : "Abdeen is an awesome person"}</p>
                    <a href="${sportNew.url}" class="btn btn-dark mt-2">Go To Source</a>
                </div>
            </div>
        `
        row.appendChild(div)
    }

}

document.addEventListener("DOMContentLoaded" , renderSportsNews)