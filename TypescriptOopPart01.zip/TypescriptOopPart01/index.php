<?php

    class Employee { 
        public function __construct() { }
    }

    $emp = new Employee();