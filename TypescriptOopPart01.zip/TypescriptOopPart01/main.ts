// Syntax With Type
// let user : string = "Abdelrahman";
// let age : number;
// let isAuth : boolean;
// let student : object;
// let students : Array<string | object> = ["" , {}]

// function greeting() : void { 
//     console.log()
// }

console.log("Welcome From Typescript")

/**
 * Encapsulation 
 * Data + Actions => Class (Make Data Private)
 * Information Or Data Hiding => Encapsulation
 */
class Student { 
    // Data Members , Fields , Attributes => Variables 
    private id : number;
    private name : string;
    private points : number;

    // Paramterized Constructor (Initialized Data  Members)
    constructor(id : number = 0 , n : string = "" , pts : number = 0) {
        this.id = id
        this.name = n
        this.points = pts
    }

    // Properties
    // Write Setter Accessor 
    public set Points(p:number) { 
        if(p > this.points) { 
            this.points = p
        }
    }
    // Read Getter Accessor
    public get Points() : number { 
        return this.points
    }
    // Method
    public checkPassOrFail() : void { 
        if(this.points >= 70) { 
            console.log("Pass")
        }else { 
            console.log("Fail")
        }
    }
}

const std1 = new Student(1 , "Ahmed" , 55) 
const std2 = new Student(2 , "Merhan" , 90)
// std1.Points = 80
std1.checkPassOrFail() 
std2.checkPassOrFail()