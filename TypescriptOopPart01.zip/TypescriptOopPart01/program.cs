using System;

class Student { 
    public Student() { }
}

class Program { 

    void main()  {
        var std = new Student();
    }
}