class Person:
    def __init__(self):
        pass

p = Person()